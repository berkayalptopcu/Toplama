﻿namespace WindowsFormsApp1
{
    partial class FrmToplama
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnToplama = new System.Windows.Forms.Button();
            this.lblbirincisayi = new System.Windows.Forms.Label();
            this.txtbirincisayi = new System.Windows.Forms.TextBox();
            this.txtikincisayi = new System.Windows.Forms.TextBox();
            this.lblikincisayi = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnToplama
            // 
            this.btnToplama.Location = new System.Drawing.Point(144, 176);
            this.btnToplama.Name = "btnToplama";
            this.btnToplama.Size = new System.Drawing.Size(255, 65);
            this.btnToplama.TabIndex = 1;
            this.btnToplama.Text = "Topla";
            this.btnToplama.UseVisualStyleBackColor = true;
            this.btnToplama.Click += new System.EventHandler(this.toplam);
            // 
            // lblbirincisayi
            // 
            this.lblbirincisayi.AutoSize = true;
            this.lblbirincisayi.Location = new System.Drawing.Point(92, 74);
            this.lblbirincisayi.Name = "lblbirincisayi";
            this.lblbirincisayi.Size = new System.Drawing.Size(81, 17);
            this.lblbirincisayi.TabIndex = 2;
            this.lblbirincisayi.Text = "Birinci Sayı:";
            this.lblbirincisayi.Click += new System.EventHandler(this.Label1_Click);
            // 
            // txtbirincisayi
            // 
            this.txtbirincisayi.Location = new System.Drawing.Point(167, 74);
            this.txtbirincisayi.Name = "txtbirincisayi";
            this.txtbirincisayi.Size = new System.Drawing.Size(255, 22);
            this.txtbirincisayi.TabIndex = 3;
            this.txtbirincisayi.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // txtikincisayi
            // 
            this.txtikincisayi.Location = new System.Drawing.Point(167, 102);
            this.txtikincisayi.Name = "txtikincisayi";
            this.txtikincisayi.Size = new System.Drawing.Size(255, 22);
            this.txtikincisayi.TabIndex = 5;
            // 
            // lblikincisayi
            // 
            this.lblikincisayi.AutoSize = true;
            this.lblikincisayi.Location = new System.Drawing.Point(92, 105);
            this.lblikincisayi.Name = "lblikincisayi";
            this.lblikincisayi.Size = new System.Drawing.Size(74, 17);
            this.lblikincisayi.TabIndex = 4;
            this.lblikincisayi.Text = "İkinci Sayı:";
            this.lblikincisayi.Click += new System.EventHandler(this.Lblikincisayi_Click);
            // 
            // FrmToplama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 351);
            this.Controls.Add(this.txtikincisayi);
            this.Controls.Add(this.lblikincisayi);
            this.Controls.Add(this.txtbirincisayi);
            this.Controls.Add(this.lblbirincisayi);
            this.Controls.Add(this.btnToplama);
            this.Name = "FrmToplama";
            this.Text = "Toplama İşlemi";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnToplama;
        private System.Windows.Forms.Label lblbirincisayi;
        private System.Windows.Forms.TextBox txtbirincisayi;
        private System.Windows.Forms.TextBox txtikincisayi;
        private System.Windows.Forms.Label lblikincisayi;
    }
}

