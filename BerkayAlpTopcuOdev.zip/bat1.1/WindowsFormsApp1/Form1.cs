﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FrmToplama : Form
    {
        public FrmToplama()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Lblikincisayi_Click(object sender, EventArgs e)
        {

           



        }

        private void toplam(object sender, EventArgs e)
        {
            int birincisayi, ikincisayi, toplam;
            birincisayi = Convert.ToInt32(txtbirincisayi.Text);
            ikincisayi = Convert.ToInt32(txtikincisayi.Text);

            toplam = birincisayi + ikincisayi;


            MessageBox.Show("Toplam: " + toplam);

        }
    }
}
